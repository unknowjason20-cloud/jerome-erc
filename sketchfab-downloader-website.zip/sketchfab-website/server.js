import express from "express";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(os.tmpdir(), "sf-downloader-jobs");
await fs.mkdir(DATA_DIR, { recursive: true });
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/frontend", express.static(path.join(__dirname, "frontend")));

const jobs = new Map();
const history = [];
const settings = new Map();
const uidPattern = /(?:sketchfab\.com\/(?:3d-models\/[^/?#]+-|models\/))?([a-f0-9]{32})/i;
function parseUid(value) {
  const match = String(value || "").trim().match(uidPattern);
  if (!match) throw new Error("Enter a valid Sketchfab model URL or 32-character model UID.");
  return match[1].toLowerCase();
}
function safeName(value) {
  return String(value || "sketchfab-model").replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").slice(0, 140);
}
function pushLog(job, message, level="info") {
  const entry = { at: new Date().toISOString(), level, message: String(message) };
  job.logs.push(entry);
  if (job.logs.length > 600) job.logs.shift();
  job.updatedAt = entry.at;
}
function serialize(job) {
  return { id:job.id, uid:job.uid, url:job.url, status:job.status, progress:job.progress,
    stage:job.stage, name:job.name, author:job.author, fileName:job.fileName,
    fileBytes:job.fileBytes, error:job.error, logs:job.logs, createdAt:job.createdAt,
    updatedAt:job.updatedAt };
}
function optionsFrom(body={}) {
  return {
    downloadTextures: body.downloadTextures === true,
    devMode: body.devMode === true,
    packMode: body.packMode === "glb" ? "glb" : "full",
    maxTextureEdge: [0,2048,4096].includes(Number(body.maxTextureEdge)) ? Number(body.maxTextureEdge) : 0
  };
}

// A Chrome storage compatibility layer for original modules that read preferences.
// Per-request options are passed explicitly to the untouched downloader pipeline.
const storage = new Map();
globalThis.chrome = {
  storage: { local: {
    async get(keys) {
      const names = Array.isArray(keys) ? keys : [keys];
      const out = {}; for (const key of names) if (storage.has(key)) out[key] = storage.get(key);
      return out;
    },
    async set(values) { for (const [key,value] of Object.entries(values)) storage.set(key,value); }
  }},
  i18n: { getUILanguage: () => "en" }
};
const { downloadModel } = await import("./lib/pipeline.js");

async function runJob(job, opts) {
  job.status = "running"; job.progress = 1; job.stage = "Starting";
  pushLog(job, `Starting download for ${job.uid}`);
  try {
    const result = await downloadModel(job.url, (line) => {
      pushLog(job, line);
      job.stage = line;
      const match = line.match(/(\d{1,3})%/);
      if (match) job.progress = Math.max(job.progress, Math.min(94, Number(match[1])));
    }, opts);
    if (!(result.zip instanceof Uint8Array) || !result.zip.length) throw new Error("Pipeline returned no ZIP bytes.");
    const fileName = safeName(result.zipName || `${job.uid}.zip`);
    const filePath = path.join(DATA_DIR, `${job.id}-${fileName}`);
    await fs.writeFile(filePath, result.zip, { flag: "wx" });
    const stat = await fs.stat(filePath);
    if (!stat.size) throw new Error("Generated archive is empty.");
    job.filePath = filePath; job.fileName = fileName; job.fileBytes = stat.size;
    job.name = result.name; job.author = result.author; job.hasGlb = !!result.hasGlb;
    job.status = "completed"; job.progress = 100; job.stage = "Archive ready";
    pushLog(job, `Verified archive ${fileName} (${stat.size} bytes)`);
    history.unshift({ id:job.id, uid:job.uid, name:job.name, fileName, status:"completed", at:job.updatedAt });
    if (history.length > 100) history.pop();
  } catch (error) {
    job.status = "failed"; job.error = error?.message || String(error); job.stage = "Failed";
    pushLog(job, job.error, "error");
    history.unshift({ id:job.id, uid:job.uid, status:"failed", error:job.error, at:job.updatedAt });
  }
}
app.get("/api/health", (_req,res) => res.json({ ok:true, service:"sketchfab-downloader-web", pipeline:"original-lib/pipeline.js" }));
app.post("/api/jobs", async (req,res) => {
  try {
    const urls = Array.isArray(req.body.urls) ? req.body.urls : [req.body.url];
    const normalized = [...new Set(urls.filter(Boolean).map(v => String(v).trim()).filter(Boolean))];
    if (!normalized.length) return res.status(400).json({ error:"Provide at least one model URL." });
    if (normalized.length > 50) return res.status(400).json({ error:"Maximum 50 URLs per batch." });
    const opts = optionsFrom(req.body);
    const created = [];
    for (const url of normalized) {
      const uid = parseUid(url);
      const id = crypto.randomUUID();
      const job = { id, uid, url: url.match(/^https?:\/\//i) ? url : `https://sketchfab.com/3d-models/${uid}`,
        status:"queued", progress:0, stage:"Queued", logs:[], createdAt:new Date().toISOString(), updatedAt:new Date().toISOString() };
      jobs.set(id,job); created.push(job);
    }
    // Sequential processing mirrors the extension's bulk queue and bounds memory for large 4K jobs.
    (async () => { for (const job of created) await runJob(job, opts); })();
    res.status(202).json({ jobs:created.map(serialize) });
  } catch (error) { res.status(400).json({ error:error.message || String(error) }); }
});
app.get("/api/jobs/:id", (req,res) => {
  const job = jobs.get(req.params.id); if (!job) return res.status(404).json({error:"Job not found."});
  res.json(serialize(job));
});
app.get("/api/jobs/:id/download", async (req,res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({error:"Job not found."});
  if (job.status !== "completed" || !job.filePath) return res.status(409).json({error:"The archive is not ready."});
  try {
    await fs.access(job.filePath);
    res.download(job.filePath, job.fileName, async (err) => {
      if (!err) { await fs.rm(job.filePath,{force:true}).catch(()=>{}); job.filePath=null; }
    });
  } catch { res.status(410).json({error:"Archive expired; run the download again."}); }
});
app.get("/api/history", (_req,res) => res.json({ history }));
app.get("/api/settings", (_req,res) => res.json({ settings:Object.fromEntries(settings) }));
app.put("/api/settings", (req,res) => {
  const value=req.body||{}; const key=String(req.headers["x-client-id"]||"default").slice(0,100);
  const normalized={textures:value.textures===true,devMode:value.devMode===true,theme:value.theme==="dark"?"dark":"light",
    lang:["en","ru","zh"].includes(value.lang)?value.lang:"en",packMode:value.packMode==="glb"?"glb":"full",
    maxTextureEdge:[0,2048,4096].includes(Number(value.maxTextureEdge))?Number(value.maxTextureEdge):0};
  settings.set(key,normalized); res.json({settings:normalized});
});
app.get("/api/logs", (_req,res) => res.json({ jobs:[...jobs.values()].map(serialize).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)) }));
app.use((err,_req,res,_next) => { console.error(err); res.status(500).json({error:"Internal server error."}); });
app.listen(PORT, () => console.log(`Sketchfab Downloader web app listening on ${PORT}`));
