# Sketchfab Downloader — standalone website conversion

This project wraps the original downloader's processing pipeline in an Express website. The complete original archive is retained under `original-source/sketchfab-downloader-extension-main/`; the runtime `lib/` is copied from the original, with one Node-compatible WASM-loading change in `lib/decrypt.js`.

## Run locally

Requirements: Node.js 20+.

```sh
npm install
npm start
```

Open `http://localhost:3000`. The backend API is under `/api`.

## Render deployment

1. Push this folder to a GitHub repository.
2. In Render, choose **New → Blueprint**, select the repository, and apply `render.yaml`.
3. Render runs `npm install` and `npm start`; health check is `/api/health`.

Generated archives are written to `DATA_DIR` (default: OS temporary directory) and removed after successful delivery. Render's local filesystem is ephemeral; completed archives are not durable across deploys/restarts. Long-running or very large model jobs can exceed free-instance memory/time limits. For production durability, configure an object-storage adapter and a persistent job store.

## Original pipeline retained

`lib/pipeline.js` remains the real processing entry point. It uses the original `sf-api.js`, `decrypt.js`, `descramble.js`, `wasm/decrypt.wasm`, `osgjs2gltf.js`, `orm.js`, `zip.js`, and supporting modules. The server does not return a success result until the ZIP has been written and checked for non-zero size.

The website supports single jobs and sequential bulk jobs, URL/UID parsing, progress/log polling, texture on/off, Original/2K/4K limits, Full/GLB-only archive mode, theme, language preference storage, developer diagnostics, and download history.

## Feature parity inventory and known boundary

See `FEATURE-MAP.md` for source-to-website mapping. The extension's `content/viewer-inject.js`, `content/webgl-hook.js`, `content/boot-hook.js`, `content/panel.js`, and `content/panel.css` depend on Chrome content-script execution in Sketchfab's page context and WebGL interception. A normal standalone website cannot inject into an unrelated Sketchfab origin. The website therefore runs the same server-side public API + decrypt + descramble + conversion pipeline; it does not have the original viewer GPU-captured texture fallback. The pipeline itself logs `MISSING_BLIT.txt` for maps it cannot decode, consistent with the original behavior. No fake viewer-capture implementation is included.

## Settings and language

English, Russian, and Chinese language resources are preserved in `_locales/` and original `lib/i18n.js`. The web dashboard currently exposes the language preference selector and stores the selected language; full dashboard string localization is not yet wired. Original extension UI strings and localized bulk UI are preserved in the archived source.

## Tests

Run the preserved original suite with `npm test`. Tests cover the original algorithms and converters; they do not by themselves prove live Sketchfab network access or end-to-end downloads. Use a public model URL for a live integration test.
