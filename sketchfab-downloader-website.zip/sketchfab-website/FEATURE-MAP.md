# Feature mapping

| Original feature / source | Website implementation | Status / verification |
|---|---|---|
| URL/UID parsing — `lib/sf-api.js`, `bulk/bulk.js` | `server.js` parser + bulk URL parser in `frontend/app.js` | Implemented; API validation test pending |
| Public viewer metadata + static-key extraction — `lib/sf-api.js` | Original pipeline invoked by backend job runner | Preserved; requires live model test |
| `.binz` decrypt — `lib/decrypt.js`, `lib/wasm/decrypt.wasm` | Original WASM pipeline; Node file-loader adapter in runtime copy | Preserved; unit/live test required |
| Texture extraction/descramble — `lib/sf-api.js`, `lib/descramble.js` | Original pipeline, texture setting and max edge options | Preserved; no viewer GPU capture parity |
| ORM/material/geometry processing — `lib/orm.js`, `lib/osgjs2gltf.js`, `lib/osg-scene.js`, `lib/osg-codec.js`, `lib/skin.js` | Original runtime `lib/` modules | Preserved |
| GLB and external glTF export — `lib/osgjs2gltf.js`, `lib/pipeline.js` | Original pipeline | Preserved |
| ZIP creation — `lib/zip.js` | Original pipeline; backend writes ZIP to temporary storage | Preserved |
| Full / GLB-only archive — `lib/pipeline.js`, popup settings | Website archive selector passed to pipeline | Implemented |
| Textures toggle + Original/2K/4K — `lib/settings.js`, popup | Main controls and Settings panel | Implemented |
| Bulk queue — `bulk/bulk.js` | `/api/jobs` sequential queue + dashboard cards | Implemented; batch stop-after-current UI not yet ported |
| Progress/logs — `lib/ui-progress.js`, `lib/devlog.js`, background/offscreen | Job polling, log endpoint, diagnostics view | Implemented; percent is stage-based, not byte-level |
| Theme/language — `lib/settings.js`, `lib/i18n.js`, `_locales/` | Theme works; language preference persists; translations retained | Partial: dashboard translations not yet wired |
| Viewer GPU texture capture — `content/viewer-inject.js`, `content/webgl-hook.js`, `content/boot-hook.js` | No direct normal-web equivalent; documented limitation | Not equivalent; browser same-origin boundary |
| Floating panel / popup — `content/panel.js`, `popup/` | Standalone dashboard | Website UX implemented; active-tab detection is not applicable |
| Extension save/download APIs — `lib/save.js`, `background.js`, `offscreen/` | Express download endpoint serves generated archive | Replaced |
| Developer mode / download log — `lib/devlog.js`, `lib/pipeline.js` | Diagnostics toggle; original pipeline embeds download log | Implemented |
| License, icons, locale packs, original tests | `original-source/`, `LICENSE`, `tests/` | Preserved |
